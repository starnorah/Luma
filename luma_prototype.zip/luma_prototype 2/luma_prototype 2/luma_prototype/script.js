document.addEventListener('DOMContentLoaded', () => {
    
    // --- Dark Mode Toggle (Study Mode) ---
    const darkModeToggle = document.getElementById('darkModeToggle');
    const body = document.body;

    darkModeToggle.addEventListener('click', () => {
        if (body.getAttribute('data-theme') === 'dark') {
            body.removeAttribute('data-theme');
            darkModeToggle.innerHTML = '<i class="fa-solid fa-moon"></i> Study Mode';
        } else {
            body.setAttribute('data-theme', 'dark');
            darkModeToggle.innerHTML = '<i class="fa-solid fa-sun"></i> Light Mode';
        }
        
        // Re-render chart to update colors based on theme
        if(window.gpaChartInstance) {
            updateChartColors();
            window.gpaChartInstance.update();
        }
    });

    // Auto-trigger dark mode if it's late (simulating 'Smart Dark Mode')
    const currentHour = new Date().getHours();
    if (currentHour >= 20 || currentHour < 6) {
        body.setAttribute('data-theme', 'dark');
        darkModeToggle.innerHTML = '<i class="fa-solid fa-sun"></i> Light Mode';
    }


    // --- Smart Pause Demo (Mindfulness Feature) ---
    const triggerBtn = document.getElementById('triggerPauseBtn');
    const resumeBtn = document.getElementById('resumeBtn');
    const pauseOverlay = document.getElementById('smartPauseOverlay');

    triggerBtn.addEventListener('click', () => {
        pauseOverlay.classList.remove('hidden');
    });

    resumeBtn.addEventListener('click', () => {
        pauseOverlay.classList.add('hidden');
    });


    // --- Set Mental Battery Gauge ---
    const setBatteryLevel = (percentage) => {
        const circle = document.querySelector('.progress');
        // Circumference = 2 * Math.PI * r = 2 * Math.PI * 45 = ~282.7
        const circumference = 282.7;
        const offset = circumference - (percentage / 100) * circumference;
        circle.style.strokeDashoffset = offset;
        
        const statusEl = document.querySelector('.status');
        const progressEl = document.querySelector('.progress');
        if(percentage < 40) {
            statusEl.textContent = 'Low Energy';
            statusEl.style.color = 'var(--luma-danger)';
            progressEl.style.stroke = 'var(--luma-danger)';
        } else if (percentage < 70) {
            statusEl.textContent = 'Moderate';
            statusEl.style.color = 'var(--luma-warning)';
            progressEl.style.stroke = 'var(--luma-warning)';
        } else {
            statusEl.textContent = 'Optimal Glow';
            statusEl.style.color = 'var(--luma-neom)';
            progressEl.style.stroke = 'var(--luma-neom)';
        }
    };

    // Initial setting
    setTimeout(() => {
        setBatteryLevel(75); // Simulate loading data
    }, 500);


    // --- GPA Progression Chart (Chart.js) ---
    const ctx = document.getElementById('gpaChart').getContext('2d');
    
    // Function to get computed css variables
    const getCssVar = (varName) => getComputedStyle(document.documentElement).getPropertyValue(varName).trim();

    let chartTextColor = '#718096'; // default
    let gridColor = 'rgba(0,0,0,0.05)';

    const updateChartColors = () => {
        const isDark = document.body.getAttribute('data-theme') === 'dark';
        chartTextColor = isDark ? '#cbd5e1' : '#718096';
        gridColor = isDark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.05)';
        
        if (window.gpaChartInstance) {
            window.gpaChartInstance.options.scales.x.ticks.color = chartTextColor;
            window.gpaChartInstance.options.scales.y.ticks.color = chartTextColor;
            window.gpaChartInstance.options.scales.x.grid.color = gridColor;
            window.gpaChartInstance.options.scales.y.grid.color = gridColor;
        }
    };
    
    updateChartColors();

    const data = {
        labels: ['Sem 1', 'Sem 2', 'Sem 3', 'Sem 4 (Current)', 'Predicted'],
        datasets: [
            {
                label: 'Cumulative GPA',
                data: [3.5, 3.65, 3.6, 3.85, 4.2], // Example progression
                borderColor: '#0d9488', // luma-teal
                backgroundColor: 'rgba(13, 148, 136, 0.1)',
                borderWidth: 2,
                pointBackgroundColor: '#0d9488',
                 pointRadius: 4,
                pointHoverRadius: 6,
                fill: true,
                tension: 0.4 // smooth curves
            },
            {
                label: 'Target Path',
                data: [null, null, null, 3.85, 4.5], // Dotted line from current to target
                borderColor: '#8b5cf6', // luma-purple
                borderDash: [5, 5],
                borderWidth: 2,
                pointBackgroundColor: '#8b5cf6',
                pointRadius: 4,
                fill: false,
                tension: 0.1
            }
        ]
    };

    const config = {
        type: 'line',
        data: data,
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false // Hide default legend to keep UI clean
                },
                tooltip: {
                    backgroundColor: 'rgba(0,0,0,0.8)',
                    padding: 10,
                    cornerRadius: 8,
                    displayColors: false,
                    callbacks: {
                        label: function(context) {
                            return `GPA: ${context.parsed.y}`;
                        }
                    }
                }
            },
            scales: {
                y: {
                    min: 3.0,
                    max: 5.0,
                    grid: {
                        color: gridColor,
                        drawBorder: false
                    },
                    ticks: {
                        color: chartTextColor,
                        stepSize: 0.5
                    }
                },
                x: {
                    grid: {
                        display: false
                    },
                    ticks: {
                        color: chartTextColor
                    }
                }
            },
            interaction: {
                intersect: false,
                mode: 'index',
            },
        }
    };

    window.gpaChartInstance = new Chart(ctx, config);

});
